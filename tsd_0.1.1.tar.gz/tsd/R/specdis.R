#' This function is used to calculate the spectral distance of two networks.
#'
#' @param t1 The matrix representation of the first network, such as the normalized Laplace matrix.
#' @param t2 The matrix representation of the second network, such as the normalized Laplace matrix.
#'
#' @return The spectral distance of the two networks.
#' @export
#'
#' @examples
#' data(graphexample)
#' adj1=graphexample[1:10,1:10]
#' adj2=graphexample[1:10,11:20]
#' L1=normlapmatrix(adj1,10)
#' L2=normlapmatrix(adj2,10)
#' d=specdis(L1,L2)
specdis<-function(t1,t2){
  #This function is used to calculate the spectral distance,
  #where the distance is the classical Euclidean distance.
  e1<-eigen(t1)
  e2<-eigen(t2)
  f1<-as.matrix(sort(e1[["values"]]))
  f2<-as.matrix(sort(e2[["values"]]))
  specdis<-sum((f1-f2)^2)^(1/2)
  return(specdis)
}
