#' The function is used to find the label of the nearest neighbors.
#'
#' @param d Distance matrix
#' @param ds The sorted distance matrix.
#' @param i The label of node i.
#' @param k The parameters of the kNN network.
#'
#' @return The labels of the k nearest neighbors.
#'
#'
#'
knnfind<-function(d,ds,i,k){
  di=t(as.matrix(d[i,]))
  k1=k+1
  sk=ds[i,k1]
  ci=ifelse(di<=sk,1,0)
  return(ci)
}
