#' This function is used to calculate the normalized Laplace matrix of the network.
#'
#' @param t The adjacency matrix of the network.
#' @param n The number of network nodes.
#'
#' @return A normalized Laplace matrix.
#' @export
#'
#' @examples
#' data(graphexample)
#' adj2=graphexample[1:10,11:20]
#' L2=normlapmatrix(adj2,10)
normlapmatrix<-function(t,n){
  d<-as.matrix(apply(t,1,sum))#计算节点的度
  deg<-d%*%t(d)
  LM<-matrix(0,n,n)#计算规范拉普拉斯矩阵
  for(i in 1:n){
    for(j in 1:n){
      if (t[i,j]==1){LM[i,j]<--1/(deg[i,j])^(1/2)
      }
    }
  }
  for (i in 1:n){
    LM[i,i]<-1
  }
  return(LM)
}
