#' Discrete TSD between networks.
#'
#' @param w1 The adjacency matrix of the first network.
#' @param w2 The adjacency matrix of the second network.
#' @param k The vector k is used to calculate the sequence of kNN networks, where k[1] and k[2] determine the range of values, and k[3] is the interval length.
#'
#' @return TSD
#' @export
#'
#' @examples
#' data(graphexample)
#' adj1=graphexample[1:10,1:10]
#' adj2=graphexample[1:10,11:20]
#' tsd12=discretetsd(adj1,adj2,c(1,9,1))
discretetsd<-function(w1,w2,k){
  library(NetworkToolbox)
  n<-dim(w1)
  k1<-seq(k[1],k[2],k[3])
  m=length(k1)
  d1<-distance(w1,weighted = FALSE)
  d2<-distance(w2,weighted = FALSE)
  t1 = array(0, dim = c(n[1],n[2],m))
  t2 = array(0, dim = c(n[1],n[2],m))
  for(i in 1:m){
    t1[,,i]=networkknn(d1,k1[i])
    t2[,,i]=networkknn(d2,k1[i])
  }
  L1 = array(0, dim = c(n[1],n[2],m))
  L2 = array(0, dim = c(n[1],n[2],m))
  for(i in 1:m){
    L1[,,i]=normlapmatrix(t1[,,i],n[1])
    L2[,,i]=normlapmatrix(t2[,,i],n[1])
  }
  Lapd<-matrix(0,m,1)
  for(i in 1:m){
    Lapd[i,1]<-specdis(L1[,,i],L2[,,i])
  }
  tsd=mean(Lapd)
  Lap<-cbind(k1,Lapd)
  output<-list(tsd=tsd,Lap=Lap,t1=t1,t2=t2)
  return(output)
}
