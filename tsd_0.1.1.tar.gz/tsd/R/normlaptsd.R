#' This function calculates the TSD value.
#'
#' @param d1 The distance matrix for the first point set.
#' @param d2 The second matrix for the first point set.
#' @param k The vector k is used to generate kNN network sequences. The first and second components are the range of values for k, and the third component is the length of the interval between adjacent parameters.
#'
#' @return A tsd value.
#' @export
#'
#' @examples
#' data(exampledim2)
#' p1=exampledim2[,c(1,2)]
#' p2=exampledim2[,c(3,4)]
#' d1=as.matrix(dist(p1))
#' d2=as.matrix(dist(p2))
#' tsd = normlaptsd(d1,d2,c(1,499,1))
normlaptsd<-function(d1,d2,k){
  #This function is used to compute the TSD based on the normal Laplacian matrix spectrum,
  #where the inputs d1 and d2 are distance matrices and k is a vector specifying the parameters of the kNN network.
  n=dim(d1)
  ds1=t(apply(d1, 1, sort))
  ds2=t(apply(d2, 1, sort))
  k1<-seq(k[1],k[2],k[3])
  m=length(k1)
  t1 = array(0, dim = c(n[1],n[2],m))
  t2 = array(0, dim = c(n[1],n[2],m))
  for(i in 1:m){
    t1[,,i]=knnnetwork(d1,ds1,k1[i])
    t2[,,i]=knnnetwork(d2,ds2,k1[i])
  }
  L1 = array(0, dim = c(n[1],n[2],m))
  L2 = array(0, dim = c(n[1],n[2],m))
  for(i in 1:m){
    L1[,,i]=normlapmatrix(t1[,,i],n[1])
    L2[,,i]=normlapmatrix(t2[,,i],n[1])
  }
  Lapd<-matrix(0,m,1)
  for(i in 1:m){
    Lapd[i,1]<-specdis(L1[,,i],L2[,,i])
  }
  tsd=mean(Lapd)
  Lap<-cbind(k1,Lapd)
  output<-list(tsd=tsd,Lap=Lap,t1=t1,t2=t2)
  return(output)
}
