#' This function is used to calculate the kNN network of a network.
#'
#' @param d The shortest distance matrix of the network.
#' @param k Parameter of the kNN network.
#'
#' @return Adjacency matrix
#' @export
#'
#' @examples
#' data(graphexample)
#' adj1=graphexample[1:10,1:10]
#' library(NetworkToolbox)
#' d1=distance(adj1,weighted = FALSE)
#' knn2=networkknn(d1,2)
networkknn<-function(d,k){
  t=ifelse(d<=k,1,0)
  diag(t)=0
  return(t)
}
